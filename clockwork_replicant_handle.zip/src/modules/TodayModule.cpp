#include "TodayModule.h"
#include <Message.h>
#include <Font.h>
#include <View.h>
#include <StringView.h>
#include <ctime>
#include <ViewPrivate.h>
#include <stdio.h>
#include <PopUpMenu.h>
#include <MenuItem.h>
#include <Application.h>

TodayModuleView::TodayModuleView()
    : BView("TodayModuleView", B_WILL_DRAW | B_FULL_UPDATE_ON_RESIZE),
      fToday(std::time(nullptr), true)
{
    SetViewColor(ui_color(B_PANEL_BACKGROUND_COLOR));
    SetFlags(Flags() | B_PULSE_NEEDED | B_SUPPORTS_LAYOUT);
    SetLowColor(ViewColor());
    SetHighColor(0, 0, 0);
    SetDrawingMode(B_OP_OVER);
    SetFont(be_plain_font);
    SetFontSize(14.0f);

    ShowReplicantHandle(true);
    UpdateContent();
}

TodayModuleView::TodayModuleView(BMessage* archive)
    : BView(archive),
      fToday(std::time(nullptr), true)
{
    SetViewColor(ui_color(B_PANEL_BACKGROUND_COLOR));
    SetFlags(Flags() | B_PULSE_NEEDED | B_SUPPORTS_LAYOUT);
    SetLowColor(ViewColor());
    SetHighColor(0, 0, 0);
    SetDrawingMode(B_OP_OVER);
    SetFont(be_plain_font);
    SetFontSize(14.0f);

    ShowReplicantHandle(true);
    UpdateContent();
}

TodayModuleView::~TodayModuleView() {}

void TodayModuleView::AttachedToWindow() {
    BView::AttachedToWindow();
    SetFont(be_plain_font);
}

void TodayModuleView::Draw(BRect updateRect) {
    BView::Draw(updateRect);
    
    float y = 15.0f;
    DrawString(fDateString.String(), BPoint(10, y));
    y += 15.0f;

    if (!fHoliday.IsEmpty()) {
        BString line("Holiday: ");
        line += fHoliday;
        DrawString(line.String(), BPoint(10, y));
        y += 15.0f;
    }

    if (!fParsha.IsEmpty()) {
        BString line("Parsha: ");
        line += fParsha;
        DrawString(line.String(), BPoint(10, y));
    }
}

status_t TodayModuleView::Archive(BMessage* into, bool deep) const {
    status_t err = BView::Archive(into, deep);
    if (err != B_OK) return err;
    into->AddString("class", "TodayModuleView");
    return B_OK;
}

BArchivable* TodayModuleView::Instantiate(BMessage* from) {
    if (validate_instantiation(from, "TodayModuleView"))
        return new TodayModuleView(from);
    return nullptr;
}

void TodayModuleView::UpdateContent() {
    fDateString = fToday.ToStringShort().c_str();
    fParsha = fToday.ToParsha().c_str();
    fHoliday = fToday.ToHolidayName().c_str();
}

void TodayModuleView::MouseDown(BPoint where) {
    BView::MouseDown(where);
    int32 buttons = 0;
    if (Window() && Window()->CurrentMessage())
        Window()->CurrentMessage()->FindInt32("buttons", &buttons);

    if ((buttons & B_SECONDARY_MOUSE_BUTTON) != 0 && IsReplicant()) {
        BPopUpMenu* menu = new BPopUpMenu("ReplicantMenu", false, false);
        menu->SetAsyncAutoDestruct(true);

        BMessage* removeMsg = new BMessage(B_DELETE_PROPERTY);
        removeMsg->AddSpecifier("Replicant");
        removeMsg->AddSpecifier("Shelf");
        removeMsg->AddSpecifier("View", Name());

        menu->AddItem(new BMenuItem("Remove replicant", removeMsg));
        ConvertToScreen(&where);
        menu->Go(where, true, true, true);
    }
}

B_DEFINE_VIEW_FACTORY(TodayModuleView);
