#pragma once

#include <string>
#include <ctime>

class HebrewDate {
public:
    HebrewDate(int hYear, int hMonth, int hDay);
    HebrewDate(std::time_t gTime, double latitude = 0.0, double longitude = 0.0);

    int Day() const;
    int Month() const;
    int Year() const;

    std::string ToStringShort() const;
    std::string ToParsha() const;
    std::string ToHolidayName() const;

    std::time_t ToGregorianTimeT() const;

private:
    int hYear_;
    int hMonth_;
    int hDay_;
};
