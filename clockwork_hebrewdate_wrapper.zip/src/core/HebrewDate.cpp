#include "HebrewDate.h"
#include <hdate.h>
#include <sstream>
#include <iomanip>

HebrewDate::HebrewDate(int hYear, int hMonth, int hDay)
    : hYear_(hYear), hMonth_(hMonth), hDay_(hDay) {}

HebrewDate::HebrewDate(std::time_t gTime, double lat, double lon) {
    hdate_struct h;
    getHebrewDate(&h, gTime, lat, lon);
    hYear_ = h.year;
    hMonth_ = h.month;
    hDay_ = h.day;
}

int HebrewDate::Day() const { return hDay_; }
int HebrewDate::Month() const { return hMonth_; }
int HebrewDate::Year() const { return hYear_; }

std::string HebrewDate::ToStringShort() const {
    std::ostringstream oss;
    oss << hDay_ << " " << HD_GetMonthName(hMonth_, hYear_) << " " << hYear_;
    return oss.str();
}

std::string HebrewDate::ToParsha() const {
    hdate_struct h;
    setHebrewDate(&h, hDay_, hMonth_, hYear_);
    return HD_GetParashaName(&h);
}

std::string HebrewDate::ToHolidayName() const {
    hdate_struct h;
    setHebrewDate(&h, hDay_, hMonth_, hYear_);
    return HD_GetHolydayString(&h);
}

std::time_t HebrewDate::ToGregorianTimeT() const {
    hdate_struct h;
    setHebrewDate(&h, hDay_, hMonth_, hYear_);
    return HdateToSec(&h);
}
