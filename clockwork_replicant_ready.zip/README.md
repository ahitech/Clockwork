# Clockwork

**Clockwork** is a modular, extensible, and fully native **Hebrew calendar utility** for the [Haiku Operating System](https://www.haiku-os.org/), written in modern C++. It provides a rich set of tools for exploring the Hebrew calendar, Jewish holidays, lunar phases, weekly Torah readings, and related time-based rituals.

While its primary goal is to be a powerful date conversion and Jewish calendar reference, it also subtly introduces Haiku users to the structure, rhythm, and richness of Jewish timekeeping.

---

## ✨ Features

- 📅 Display today's Hebrew and Gregorian date, Torah portion, and candle lighting time
- 🔁 Bidirectional date conversion between Hebrew and Gregorian calendars
- 🌓 Graphical lunar phase display based on the Hebrew date
- 🔢 Days between dates (cross-calendar support)
- ⏳ Countdown to next holiday or event (with custom filters)
- 🕯️ Candle lighting and Havdalah times based on geolocation
- 🕎 Virtual Hanukkiah with lighting simulation
- 📜 Weekly Parashot and Haftarah reading info
- 🔗 Optional links to Wikipedia for holidays and events
- 🧩 Highly modular drag-and-drop interface: enable, disable, rearrange modules at will
- 🧲 Replicant support: pin modules to the desktop as native Haiku views
- 🌐 Multilingual support: UI language can follow system or be overridden manually

---

## 📜 License

This project is licensed under the **GNU General Public License v2** — see [`LICENSE`](LICENSE) for details.  
This license was chosen to comply with the licensing requirements of `libhdate`, which is released under the GPL v2 or later.
