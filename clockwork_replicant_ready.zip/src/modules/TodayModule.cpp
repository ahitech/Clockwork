#include "TodayModule.h"
#include <Message.h>
#include <Font.h>
#include <View.h>
#include <StringView.h>
#include <ctime>
#include <ViewPrivate.h>
#include <stdio.h>

TodayModuleView::TodayModuleView()
    : BView("TodayModuleView", B_WILL_DRAW | B_FULL_UPDATE_ON_RESIZE),
      fToday(std::time(nullptr), true)
{
    SetViewColor(ui_color(B_PANEL_BACKGROUND_COLOR));
    UpdateContent();
}

TodayModuleView::TodayModuleView(BMessage* archive)
    : BView(archive),
      fToday(std::time(nullptr), true)
{
    SetViewColor(ui_color(B_PANEL_BACKGROUND_COLOR));
    UpdateContent();
}

TodayModuleView::~TodayModuleView() {}

void TodayModuleView::AttachedToWindow() {
    BView::AttachedToWindow();
    SetFont(be_plain_font);
    SetFontSize(14.0f);
}

void TodayModuleView::Draw(BRect updateRect) {
    BView::Draw(updateRect);
    
    float y = 15.0f;
    DrawString(fDateString.String(), BPoint(10, y));
    y += 15.0f;

    if (!fHoliday.IsEmpty()) {
        BString line("Holiday: ");
        line += fHoliday;
        DrawString(line.String(), BPoint(10, y));
        y += 15.0f;
    }

    if (!fParsha.IsEmpty()) {
        BString line("Parsha: ");
        line += fParsha;
        DrawString(line.String(), BPoint(10, y));
    }
}

status_t TodayModuleView::Archive(BMessage* into, bool deep) const {
    status_t err = BView::Archive(into, deep);
    if (err != B_OK) return err;
    into->AddString("class", "TodayModuleView");
    return B_OK;
}

BArchivable* TodayModuleView::Instantiate(BMessage* from) {
    if (validate_instantiation(from, "TodayModuleView"))
        return new TodayModuleView(from);
    return nullptr;
}

void TodayModuleView::UpdateContent() {
    fDateString = fToday.ToStringShort().c_str();
    fParsha = fToday.ToParsha().c_str();
    fHoliday = fToday.ToHolidayName().c_str();
}

// Регистрация класса как репликанта
B_DEFINE_VIEW_FACTORY(TodayModuleView);
